#include "addressbook.pb.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void ListPeople(const tutorial::AddressBook& address_book) {
  for (int i=0; i < address_book.persion_size(); ++i) {
    const tutorial::Persion& persion = address_book.persion(i);
    cout << persion.name() << " " <<persion.age() << endl;
  }
}

int main(int argc, char** argv) {
  if (argc!=2) {
    cerr << "Usage: " << argv[0] <<"ADRESS_BOOL_FILE" << endl;
    return -1;
  }

  tutorial::AddressBook address_book;
  fstream input(argv[1], ios::in | ios::binary);
  if (!address_book.ParseFromIstream(&input)) {
    cerr << "Failed to parse address book." << endl;
    return -1;
  }
  input.close();

  ListPeople(address_book);
  return 0;
}
