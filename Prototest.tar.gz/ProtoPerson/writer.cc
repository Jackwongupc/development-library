#include "addressbook.pb.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void PromptForAdress(tutorial::Persion* persion) {
  cout<< "Ether persion name:" << endl;
  string name;
  cin >> name;
  persion->set_name(name);

  int age;
  cin >> age;
  persion->set_age(age);
}

int main(int argc, char** argv) {

  if (argc!=2) {
    cerr << "Usage: " << argv[0] << "ADDRESS_BOOL_FILE" << endl;
    return -1;
  }

  tutorial::AddressBook address_book;
  fstream input(argv[1], ios::in | ios::binary);
  if (!input) {
    cout << argv[1] << ":File not found. Creating a new file."<<endl;
  } else if (!address_book.ParseFromIstream(&input)) {
    cerr << "Failed to parse address book." <<endl;
    return -1;
  }

  PromptForAdress(address_book.add_persion());
  fstream output(argv[1], ios::out | ios::trunc | ios::binary);
  if (!address_book.SerializeToOstream(&output)) {
    cerr << "Failed to write address book." <<endl;
    return -1;
  }
  return 0;
}


