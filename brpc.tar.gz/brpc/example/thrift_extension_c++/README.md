Note:
    Only thrift framed transport supported now, in another words, only working on thrift nonblocking mode.

summary:
    echo_client/echo_server:
        brpc + thrift protocol version
    native_client/native_server:
        native thrift cpp version


